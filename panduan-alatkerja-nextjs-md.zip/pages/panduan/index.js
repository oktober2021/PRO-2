import Navbar from '../../components/Navbar'
import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'

export default function Panduan({ articles }){
  return (
    <div>
      <Navbar />
      <main className="container">
        <h1 className="text-2xl font-semibold mb-4">Daftar Panduan</h1>
        <div className="grid md:grid-cols-2 gap-4">
          {articles.map(a => (
            <a key={a.slug} href={`/panduan/${a.slug}`} className="block bg-white p-4 rounded shadow">
              <h3 className="font-medium">{a.title}</h3>
              <p className="text-sm text-gray-500 mt-2">{a.category}</p>
            </a>
          ))}
        </div>
      </main>
    </div>
  )
}

export async function getStaticProps(){
  const contentDir = path.join(process.cwd(), 'content')
  const files = fs.existsSync(contentDir) ? fs.readdirSync(contentDir).filter(f=>f.endsWith('.md')) : []
  const articles = files.map(file=>{
    const raw = fs.readFileSync(path.join(contentDir, file),'utf8')
    const { data } = matter(raw)
    return { title: data.title || file.replace('.md',''), slug: data.slug || file.replace('.md',''), category: data.category || '' }
  })
  return { props: { articles } }
}
