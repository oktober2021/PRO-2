import Navbar from '../../components/Navbar'
import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import { remark } from 'remark'
import html from 'remark-html'

export default function Article({ contentHtml, meta }){
  return (
    <div>
      <Navbar />
      <main className="container">
        <article className="bg-white p-6 rounded shadow">
          <h1 className="text-2xl font-semibold mb-2">{meta.title}</h1>
          <p className="text-sm text-gray-500 mb-4">{meta.category}</p>
          <div dangerouslySetInnerHTML={{ __html: contentHtml }} />
        </article>
      </main>
    </div>
  )
}

export async function getStaticPaths(){
  const contentDir = path.join(process.cwd(), 'content')
  const files = fs.existsSync(contentDir) ? fs.readdirSync(contentDir).filter(f=>f.endsWith('.md')) : []
  const paths = files.map(f=>({ params: { slug: f.replace('.md','') } }))
  return { paths, fallback: false }
}

export async function getStaticProps({ params }){
  const slug = params.slug
  const filePath = path.join(process.cwd(), 'content', slug + '.md')
  const raw = fs.readFileSync(filePath, 'utf8')
  const { data, content } = matter(raw)
  const processed = await remark().use(html).process(content)
  const contentHtml = processed.toString()
  return { props: { meta: data, contentHtml } }
}
