import Navbar from '../components/Navbar'
import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'

export default function Home({ articles }){
  return (
    <div>
      <Navbar />
      <main className="container">
        <h1 className="text-3xl font-semibold mb-2">Panduan Alat Kerja</h1>
        <p className="text-gray-600 mb-6">Yang susah jadi gampang — koleksi panduan dan cara pakai alat.</p>

        <section className="grid md:grid-cols-2 gap-4">
          {articles.map(a => (
            <a href={`/panduan/${a.slug}`} key={a.slug} className="block bg-white p-4 rounded shadow">
              <h3 className="font-medium">{a.title}</h3>
              <p className="text-sm text-gray-500 mt-2">{a.category || ''}</p>
            </a>
          ))}
        </section>
      </main>
    </div>
  )
}

export async function getStaticProps(){
  const contentDir = path.join(process.cwd(), 'content')
  const files = fs.existsSync(contentDir) ? fs.readdirSync(contentDir).filter(f=>f.endsWith('.md')) : []
  const articles = files.map(file=>{
    const raw = fs.readFileSync(path.join(contentDir, file),'utf8')
    const { data } = matter(raw)
    return { title: data.title || file.replace('.md',''), slug: data.slug || file.replace('.md',''), category: data.category || '' }
  })
  return { props: { articles } }
}
