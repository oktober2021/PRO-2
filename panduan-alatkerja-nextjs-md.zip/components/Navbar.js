import Link from 'next/link'
export default function Navbar(){ 
  return (
    <nav className="bg-white shadow">
      <div className="container flex items-center justify-between py-4">
        <Link href="/"><a className="font-bold text-xl">Panduan Alat Kerja</a></Link>
        <div className="flex gap-4">
          <Link href="/">Beranda</Link>
          <Link href="/panduan">Panduan</Link>
        </div>
      </div>
    </nav>
  )
}
