# Panduan Alat Kerja (Markdown-driven)

Starter Next.js site where content is written as Markdown files in /content.

Quickstart (local):

1. Extract ZIP
2. Install dependencies:
   ```bash
   npm install
   npx tailwindcss init -p
   ```
   If you already have tailwind config created the project will still work.
3. Run dev:
   ```bash
   npm run dev
   ```
4. Open http://localhost:3000

Add content:
- Put `.md` files into `/content`
- Each MD file should include YAML frontmatter:
  ```yaml
  ---
  title: "Judul Artikel"
  slug: "nama-slug"
  category: "Alat Listrik"
  ---
  ```
- Then visit `/panduan/{slug}`
