---
title: "Cara Memilih dan Menggunakan Palu"
slug: "palu"
category: "Alat Tukang"
---

Palu adalah alat dasar tukang untuk memukul paku dan bentuk material.

## Jenis Palu
- Palu claw (palu paku)
- Palu ball-peen

## Cara Pakai
- Pegang pada bagian ujung gagang untuk leverage terbaik.
- Pastikan pegangan tidak retak.
