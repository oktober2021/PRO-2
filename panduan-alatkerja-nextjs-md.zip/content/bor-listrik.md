---
title: "Cara Menggunakan Bor Listrik untuk Pemula"
slug: "bor-listrik"
category: "Alat Listrik"
---

**Ringkasan**: Bor listrik sangat berguna untuk melubangi kayu, besi, dan tembok.

## Alat dan Bahan
- Bor listrik
- Bor bit sesuai material
- Kacamata pelindung

## Langkah Penggunaan
1. Periksa bit dan chuck.
2. Kencangkan bit dengan benar.
3. Pilih putaran rendah untuk material keras.
4. Jangan tekan berlebihan; biarkan bor yang bekerja.

## Tips Keselamatan
- Gunakan kacamata pelindung.
- Lepaskan listrik saat mengganti bit.
